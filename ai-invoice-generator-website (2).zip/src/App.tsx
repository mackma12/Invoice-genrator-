import { useState, useCallback, useMemo } from 'react';
import { v4 as uuidv4 } from 'uuid';
import {
  InvoiceData,
  defaultInvoice,
  templates,
} from './types';
import { generatePDF } from './utils/pdfGenerator';
import {
  generateItemDescription,
  generatePaymentTerms,
  generateInvoiceNotes,
  generateInvoiceEmail,
} from './utils/aiGenerator';
import Header from './components/Header';
import AdBanner from './components/AdBanner';
import TemplateSelector from './components/TemplateSelector';
import CompanyDetailsForm from './components/CompanyDetailsForm';
import CustomerDetailsForm from './components/CustomerDetailsForm';
import LineItemsTable from './components/LineItemsTable';
import InvoicePreview from './components/InvoicePreview';
import AIAssistant from './components/AIAssistant';
import {
  Download,
  Printer,
  Eye,
  Wand2,
  FileText,
  Mail,
  RotateCcw,
  Sparkles,
} from 'lucide-react';

type ActiveTab = 'details' | 'preview' | 'ai';
type DetailsSection = 'company' | 'customer' | 'items' | 'payment';

export default function App() {
  const [invoice, setInvoice] = useState<InvoiceData>({
    ...defaultInvoice,
    items: [{ id: uuidv4(), description: '', quantity: 1, rate: 0, gst: 18, discount: 0, aiGenerating: false }],
  });
  const [activeTab, setActiveTab] = useState<ActiveTab>('details');
  const [detailsSection, setDetailsSection] = useState<DetailsSection>('company');
  const [selectedTemplate, setSelectedTemplate] = useState('modern');
  const [aiLoading, setAiLoading] = useState(false);
  const [showEmailModal, setShowEmailModal] = useState(false);
  const [emailContent, setEmailContent] = useState('');
  const [emailTone, setEmailTone] = useState<'professional' | 'friendly' | 'formal' | 'reminder'>('professional');

  // Calculations
  const calculations = useMemo(() => {
    const subtotal = invoice.items.reduce(
      (sum, item) => sum + item.quantity * item.rate * (1 - item.discount / 100),
      0
    );
    const totalGst = invoice.items.reduce((sum, item) => {
      const amount = item.quantity * item.rate * (1 - item.discount / 100);
      return sum + amount * (item.gst / 100);
    }, 0);
    const totalDiscount = invoice.items.reduce((sum, item) => {
      const amount = item.quantity * item.rate;
      return sum + (amount * item.discount) / 100;
    }, 0);
    const grandTotal = subtotal + totalGst;
    return { subtotal, totalGst, totalDiscount, grandTotal };
  }, [invoice.items]);

  // Handlers
  const updateCompany = useCallback(
    (field: string, value: string) => {
      setInvoice((prev) => ({
        ...prev,
        company: { ...prev.company, [field]: value },
      }));
    },
    []
  );

  const updateCustomer = useCallback(
    (field: string, value: string) => {
      setInvoice((prev) => ({
        ...prev,
        customer: { ...prev.customer, [field]: value },
      }));
    },
    []
  );

  const updateItem = useCallback(
    (id: string, field: string, value: string | number | boolean) => {
      setInvoice((prev) => ({
        ...prev,
        items: prev.items.map((item) =>
          item.id === id ? { ...item, [field]: value } : item
        ),
      }));
    },
    []
  );

  const addItem = useCallback(() => {
    setInvoice((prev) => ({
      ...prev,
      items: [
        ...prev.items,
        {
          id: uuidv4(),
          description: '',
          quantity: 1,
          rate: 0,
          gst: 18,
          discount: 0,
          aiGenerating: false,
        },
      ],
    }));
  }, []);

  const removeItem = useCallback((id: string) => {
    setInvoice((prev) => ({
      ...prev,
      items: prev.items.filter((item) => item.id !== id),
    }));
  }, []);

  const updateNotes = useCallback((value: string) => {
    setInvoice((prev) => ({ ...prev, notes: value }));
  }, []);

  const updatePaymentTerms = useCallback((value: string) => {
    setInvoice((prev) => ({ ...prev, paymentTerms: value }));
  }, []);

  const updateBankDetails = useCallback((field: string, value: string) => {
    setInvoice((prev) => ({ ...prev, [field]: value }));
  }, []);

  // AI Functions
  const handleAIGenerateDescription = async (id: string, description: string) => {
    if (!description.trim()) return;
    setAiLoading(true);
    updateItem(id, 'aiGenerating', true);
    try {
      const generated = await generateItemDescription(description);
      updateItem(id, 'description', generated);
    } catch {
      console.error('Failed to generate description');
    }
    updateItem(id, 'aiGenerating', false);
    setAiLoading(false);
  };

  const handleAIGenerateTerms = async () => {
    setAiLoading(true);
    try {
      const generated = await generatePaymentTerms();
      updatePaymentTerms(generated);
    } catch {
      console.error('Failed to generate terms');
    }
    setAiLoading(false);
  };

  const handleAIGenerateNotes = async () => {
    setAiLoading(true);
    try {
      const generated = await generateInvoiceNotes();
      updateNotes(generated);
    } catch {
      console.error('Failed to generate notes');
    }
    setAiLoading(false);
  };

  const handleGenerateEmail = async () => {
    setAiLoading(true);
    try {
      const customerName = invoice.customer.name || 'Valued Customer';
      const generated = await generateInvoiceEmail(
        customerName,
        `${invoice.currency}${calculations.grandTotal.toFixed(2)}`,
        invoice.invoiceNumber,
        emailTone,
        invoice.company.name || 'Your Company'
      );
      setEmailContent(generated);
      setShowEmailModal(true);
    } catch {
      console.error('Failed to generate email');
    }
    setAiLoading(false);
  };

  const handleDownloadPDF = async (openInTab = false) => {
    await generatePDF(invoice, selectedTemplate, openInTab);
  };

  const handlePrint = () => {
    handleDownloadPDF(true);
  };

  const handleReset = () => {
    setInvoice({
      ...defaultInvoice,
      items: [{ id: uuidv4(), description: '', quantity: 1, rate: 0, gst: 18, discount: 0, aiGenerating: false }],
    });
    setSelectedTemplate('modern');
    setDetailsSection('company');
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      <AdBanner />

      {/* Hero Banner */}
      <div className="bg-gradient-to-r from-blue-600 via-blue-700 to-indigo-800 text-white">
        <div className="max-w-7xl mx-auto px-4 py-8 sm:py-12">
          <div className="flex items-center gap-3 mb-3">
            <Sparkles className="w-8 h-8 text-yellow-300" />
            <h1 className="text-3xl sm:text-4xl font-bold">AI-Powered Invoice Generator</h1>
          </div>
          <p className="text-blue-100 text-lg max-w-2xl">
            Create professional invoices in seconds. AI-powered descriptions, payment terms, and email templates. 
            Download as PDF instantly.
          </p>
        </div>
      </div>

      {/* Template Selector */}
      <div className="max-w-7xl mx-auto px-4 py-6">
        <TemplateSelector
          templates={templates}
          selected={selectedTemplate}
          onSelect={setSelectedTemplate}
        />
      </div>

      {/* Tab Navigation */}
      <div className="max-w-7xl mx-auto px-4">
        <div className="flex gap-1 bg-white rounded-xl p-1 shadow-sm border border-gray-200 mb-6">
          <button
            onClick={() => setActiveTab('details')}
            className={`flex-1 flex items-center justify-center gap-2 py-3 px-4 rounded-lg font-medium text-sm transition-all ${
              activeTab === 'details'
                ? 'bg-blue-600 text-white shadow-md'
                : 'text-gray-600 hover:bg-gray-50'
            }`}
          >
            <FileText className="w-4 h-4" />
            <span className="hidden sm:inline">Invoice Details</span>
            <span className="sm:hidden">Details</span>
          </button>
          <button
            onClick={() => setActiveTab('preview')}
            className={`flex-1 flex items-center justify-center gap-2 py-3 px-4 rounded-lg font-medium text-sm transition-all ${
              activeTab === 'preview'
                ? 'bg-blue-600 text-white shadow-md'
                : 'text-gray-600 hover:bg-gray-50'
            }`}
          >
            <Eye className="w-4 h-4" />
            <span className="hidden sm:inline">Live Preview</span>
            <span className="sm:hidden">Preview</span>
          </button>
          <button
            onClick={() => setActiveTab('ai')}
            className={`flex-1 flex items-center justify-center gap-2 py-3 px-4 rounded-lg font-medium text-sm transition-all ${
              activeTab === 'ai'
                ? 'bg-purple-600 text-white shadow-md'
                : 'text-gray-600 hover:bg-gray-50'
            }`}
          >
            <Wand2 className="w-4 h-4" />
            <span className="hidden sm:inline">AI Assistant</span>
            <span className="sm:hidden">AI</span>
          </button>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-4 pb-12">
        <div className="flex flex-col lg:flex-row gap-6">
          {/* Left Panel */}
          <div className="lg:w-3/5">
            {activeTab === 'details' && (
              <div className="space-y-6">
                {/* Invoice Settings */}
                <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
                  <h3 className="text-lg font-semibold text-gray-800 mb-4 flex items-center gap-2">
                    📋 Invoice Settings
                  </h3>
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">Invoice Number</label>
                      <input
                        type="text"
                        value={invoice.invoiceNumber}
                        onChange={(e) => setInvoice((prev) => ({ ...prev, invoiceNumber: e.target.value }))}
                        className="w-full px-4 py-2.5 rounded-lg border border-gray-300 focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-sm font-mono"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">Invoice Date</label>
                      <input
                        type="date"
                        value={invoice.invoiceDate}
                        onChange={(e) => setInvoice((prev) => ({ ...prev, invoiceDate: e.target.value }))}
                        className="w-full px-4 py-2.5 rounded-lg border border-gray-300 focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-sm"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">Due Date</label>
                      <input
                        type="date"
                        value={invoice.dueDate}
                        onChange={(e) => setInvoice((prev) => ({ ...prev, dueDate: e.target.value }))}
                        className="w-full px-4 py-2.5 rounded-lg border border-gray-300 focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-sm"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">Currency</label>
                      <select
                        value={invoice.currency}
                        onChange={(e) => setInvoice((prev) => ({ ...prev, currency: e.target.value }))}
                        className="w-full px-4 py-2.5 rounded-lg border border-gray-300 focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-sm"
                      >
                        <option value="₹">₹ INR (Indian Rupee)</option>
                        <option value="$">$ USD (US Dollar)</option>
                        <option value="€">€ EUR (Euro)</option>
                        <option value="£">£ GBP (British Pound)</option>
                        <option value="¥">¥ JPY (Japanese Yen)</option>
                        <option value="A$">A$ AUD (Australian Dollar)</option>
                        <option value="C$">C$ CAD (Canadian Dollar)</option>
                      </select>
                    </div>
                  </div>
                </div>

                {/* Section Navigation */}
                <div className="flex flex-wrap gap-2">
                  {(['company', 'customer', 'items', 'payment'] as DetailsSection[]).map(
                    (section) => (
                      <button
                        key={section}
                        onClick={() => setDetailsSection(section)}
                        className={`px-4 py-2 rounded-lg text-sm font-medium transition-all ${
                          detailsSection === section
                            ? 'bg-blue-600 text-white shadow-md'
                            : 'bg-white text-gray-600 border border-gray-200 hover:border-blue-300'
                        }`}
                      >
                        {section === 'company' && '🏢 '}
                        {section === 'customer' && '👤 '}
                        {section === 'items' && '📦 '}
                        {section === 'payment' && '💳 '}
                        {section.charAt(0).toUpperCase() + section.slice(1)}
                      </button>
                    )
                  )}
                </div>

                {detailsSection === 'company' && (
                  <CompanyDetailsForm
                    details={invoice.company}
                    onUpdate={updateCompany}
                  />
                )}

                {detailsSection === 'customer' && (
                  <CustomerDetailsForm
                    details={invoice.customer}
                    onUpdate={updateCustomer}
                  />
                )}

                {detailsSection === 'items' && (
                  <div className="space-y-6">
                    <LineItemsTable
                      items={invoice.items}
                      currency={invoice.currency}
                      onUpdate={updateItem}
                      onAdd={addItem}
                      onRemove={removeItem}
                      onAiGenerate={handleAIGenerateDescription}
                      aiLoading={aiLoading}
                    />

                    {/* Summary */}
                    <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
                      <h3 className="text-lg font-semibold text-gray-800 mb-4">Invoice Summary</h3>
                      <div className="space-y-3">
                        <div className="flex justify-between text-gray-600">
                          <span>Subtotal</span>
                          <span className="font-medium">{invoice.currency}{calculations.subtotal.toFixed(2)}</span>
                        </div>
                        {calculations.totalDiscount > 0 && (
                          <div className="flex justify-between text-red-500">
                            <span>Discount</span>
                            <span className="font-medium">-{invoice.currency}{calculations.totalDiscount.toFixed(2)}</span>
                          </div>
                        )}
                        <div className="flex justify-between text-gray-600">
                          <span>GST</span>
                          <span className="font-medium">{invoice.currency}{calculations.totalGst.toFixed(2)}</span>
                        </div>
                        <div className="border-t pt-3 flex justify-between text-lg font-bold text-gray-800">
                          <span>Grand Total</span>
                          <span className="text-blue-600">{invoice.currency}{calculations.grandTotal.toFixed(2)}</span>
                        </div>
                      </div>
                    </div>
                  </div>
                )}

                {detailsSection === 'payment' && (
                  <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6 space-y-6">
                    <div>
                      <h3 className="text-lg font-semibold text-gray-800 mb-4">Bank Details</h3>
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-1">Bank Name</label>
                          <input
                            type="text"
                            value={invoice.bankName}
                            onChange={(e) => updateBankDetails('bankName', e.target.value)}
                            className="w-full px-4 py-2.5 rounded-lg border border-gray-300 focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all text-sm"
                            placeholder="e.g., State Bank of India"
                          />
                        </div>
                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-1">Account Number</label>
                          <input
                            type="text"
                            value={invoice.accountNumber}
                            onChange={(e) => updateBankDetails('accountNumber', e.target.value)}
                            className="w-full px-4 py-2.5 rounded-lg border border-gray-300 focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all text-sm"
                            placeholder="e.g., 1234567890"
                          />
                        </div>
                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-1">IFSC Code</label>
                          <input
                            type="text"
                            value={invoice.ifscCode}
                            onChange={(e) => updateBankDetails('ifscCode', e.target.value)}
                            className="w-full px-4 py-2.5 rounded-lg border border-gray-300 focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all text-sm"
                            placeholder="e.g., SBIN0001234"
                          />
                        </div>
                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-1">Authorized Signature</label>
                          <input
                            type="text"
                            value={invoice.signature}
                            onChange={(e) => updateBankDetails('signature', e.target.value)}
                            className="w-full px-4 py-2.5 rounded-lg border border-gray-300 focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all text-sm"
                            placeholder="e.g., John Doe"
                          />
                        </div>
                      </div>
                    </div>

                    <div className="border-t pt-6">
                      <h3 className="text-lg font-semibold text-gray-800 mb-4">
                        Invoice Notes
                        <button
                          onClick={handleAIGenerateNotes}
                          disabled={aiLoading}
                          className="ml-2 inline-flex items-center gap-1 text-xs bg-purple-100 text-purple-700 px-2 py-1 rounded-full hover:bg-purple-200 transition-colors disabled:opacity-50"
                        >
                          <Sparkles className="w-3 h-3" />
                          AI Generate
                        </button>
                      </h3>
                      <textarea
                        value={invoice.notes}
                        onChange={(e) => updateNotes(e.target.value)}
                        className="w-full px-4 py-2.5 rounded-lg border border-gray-300 focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all text-sm"
                        rows={3}
                        placeholder="Add notes or thank-you message..."
                      />
                    </div>

                    <div className="border-t pt-6">
                      <h3 className="text-lg font-semibold text-gray-800 mb-4">
                        Payment Terms
                        <button
                          onClick={handleAIGenerateTerms}
                          disabled={aiLoading}
                          className="ml-2 inline-flex items-center gap-1 text-xs bg-purple-100 text-purple-700 px-2 py-1 rounded-full hover:bg-purple-200 transition-colors disabled:opacity-50"
                        >
                          <Sparkles className="w-3 h-3" />
                          AI Generate
                        </button>
                      </h3>
                      <textarea
                        value={invoice.paymentTerms}
                        onChange={(e) => updatePaymentTerms(e.target.value)}
                        className="w-full px-4 py-2.5 rounded-lg border border-gray-300 focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all text-sm"
                        rows={3}
                        placeholder="e.g., Payment is due within 15 days of the invoice date..."
                      />
                    </div>
                  </div>
                )}
              </div>
            )}

            {activeTab === 'preview' && (
              <div className="space-y-4">
                <InvoicePreview invoice={invoice} templateId={selectedTemplate} calculations={calculations} />
              </div>
            )}

            {activeTab === 'ai' && (
              <AIAssistant
                invoice={invoice}
                calculations={calculations}
                onGenerateEmail={handleGenerateEmail}
                onGenerateTerms={handleAIGenerateTerms}
                onGenerateNotes={handleAIGenerateNotes}
                onGenerateDescription={handleAIGenerateDescription}
                aiLoading={aiLoading}
              />
            )}
          </div>

          {/* Right Panel - Invoice Preview */}
          <div className="lg:w-2/5">
            <div className="sticky top-4 space-y-4">
              {/* Action Buttons */}
              <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-4">
                <div className="grid grid-cols-2 gap-3">
                  <button
                    onClick={() => handleDownloadPDF(false)}
                    className="flex items-center justify-center gap-2 bg-blue-600 text-white py-2.5 px-4 rounded-lg hover:bg-blue-700 transition-colors font-medium text-sm"
                  >
                    <Download className="w-4 h-4" />
                    Download PDF
                  </button>
                  <button
                    onClick={handlePrint}
                    className="flex items-center justify-center gap-2 bg-green-600 text-white py-2.5 px-4 rounded-lg hover:bg-green-700 transition-colors font-medium text-sm"
                  >
                    <Printer className="w-4 h-4" />
                    Print / View
                  </button>
                  <button
                    onClick={handleGenerateEmail}
                    disabled={aiLoading}
                    className="flex items-center justify-center gap-2 bg-purple-600 text-white py-2.5 px-4 rounded-lg hover:bg-purple-700 transition-colors font-medium text-sm disabled:opacity-50"
                  >
                    <Mail className="w-4 h-4" />
                    Generate Email
                  </button>
                  <button
                    onClick={handleReset}
                    className="flex items-center justify-center gap-2 bg-gray-100 text-gray-700 py-2.5 px-4 rounded-lg hover:bg-gray-200 transition-colors font-medium text-sm"
                  >
                    <RotateCcw className="w-4 h-4" />
                    Reset
                  </button>
                </div>
              </div>

              {/* Mini Preview */}
              <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
                <div className="p-3 bg-gray-50 border-b flex items-center justify-between">
                  <span className="text-sm font-medium text-gray-700">Quick Preview</span>
                  <span className="text-xs text-gray-500">{invoice.invoiceNumber}</span>
                </div>
                <div className="p-4">
                  <div
                    className="rounded-lg border border-gray-200 p-4 text-sm"
                    style={{ fontFamily: 'Inter, sans-serif' }}
                  >
                    <div className="flex justify-between items-start mb-4">
                      <div>
                        <div
                          className="font-bold text-lg"
                          style={{ color: templates.find((t) => t.id === selectedTemplate)?.primaryColor }}
                        >
                          {invoice.company.name || 'Your Company'}
                        </div>
                        <div className="text-gray-500 text-xs mt-1">{invoice.company.email}</div>
                      </div>
                      <div className="text-right">
                        <div
                          className="font-bold text-2xl"
                          style={{ color: templates.find((t) => t.id === selectedTemplate)?.primaryColor }}
                        >
                          INVOICE
                        </div>
                        <div className="text-gray-500 text-xs">#{invoice.invoiceNumber}</div>
                      </div>
                    </div>
                    <div className="text-xs text-gray-500 mb-3">
                      <span>Date: {invoice.invoiceDate}</span> • <span>Due: {invoice.dueDate}</span>
                    </div>
                    <div className="bg-gray-50 rounded-lg p-3 mb-3">
                      <div className="text-xs font-medium text-gray-500 mb-1">Bill To:</div>
                      <div className="font-medium text-gray-800">
                        {invoice.customer.name || 'Customer Name'}
                      </div>
                    </div>
                    <div className="space-y-1.5 mb-3">
                      {invoice.items.slice(0, 3).map((item, i) => (
                        <div key={item.id} className="flex justify-between text-xs">
                          <span className="text-gray-600 truncate flex-1 mr-2">
                            {item.description || `Item ${i + 1}`}
                          </span>
                          <span className="text-gray-800 font-medium whitespace-nowrap">
                            {invoice.currency}
                            {(item.quantity * item.rate * (1 - item.discount / 100) * (1 + item.gst / 100)).toFixed(2)}
                          </span>
                        </div>
                      ))}
                      {invoice.items.length > 3 && (
                        <div className="text-xs text-gray-400">+{invoice.items.length - 3} more items</div>
                      )}
                    </div>
                    <div className="border-t pt-2 flex justify-between">
                      <span className="font-bold">Total</span>
                      <span
                        className="font-bold text-lg"
                        style={{ color: templates.find((t) => t.id === selectedTemplate)?.primaryColor }}
                      >
                        {invoice.currency}{calculations.grandTotal.toFixed(2)}
                      </span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Monetization: Ad Placeholder */}
              <AdBanner variant="sidebar" />
            </div>
          </div>
        </div>
      </div>

      {/* Email Modal */}
      {showEmailModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-lg overflow-hidden">
            <div className="bg-purple-600 text-white p-4 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Mail className="w-5 h-5" />
                <h3 className="font-semibold">Invoice Email</h3>
              </div>
              <div className="flex gap-2">
                {(['professional', 'friendly', 'formal', 'reminder'] as const).map((tone) => (
                  <button
                    key={tone}
                    onClick={() => {
                      setEmailTone(tone);
                      handleGenerateEmail();
                    }}
                    className={`px-3 py-1 rounded-full text-xs font-medium transition-all ${
                      emailTone === tone
                        ? 'bg-white text-purple-600'
                        : 'bg-purple-700 text-purple-200 hover:bg-purple-500'
                    }`}
                  >
                    {tone.charAt(0).toUpperCase() + tone.slice(1)}
                  </button>
                ))}
              </div>
            </div>
            <div className="p-6">
              <textarea
                value={emailContent}
                onChange={(e) => setEmailContent(e.target.value)}
                className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:ring-2 focus:ring-purple-500 focus:border-purple-500 transition-all text-sm font-mono"
                rows={10}
              />
            </div>
            <div className="bg-gray-50 p-4 flex justify-end gap-3">
              <button
                onClick={() => setShowEmailModal(false)}
                className="px-4 py-2 rounded-lg border border-gray-300 text-gray-700 hover:bg-gray-100 text-sm font-medium"
              >
                Close
              </button>
              <button
                onClick={() => {
                  navigator.clipboard.writeText(emailContent);
                  alert('Email copied to clipboard!');
                }}
                className="px-4 py-2 rounded-lg bg-purple-600 text-white hover:bg-purple-700 text-sm font-medium"
              >
                Copy to Clipboard
              </button>
              <button
                onClick={() => {
                  const subject = `Invoice #${invoice.invoiceNumber} - ${invoice.company.name || 'Your Company'}`;
                  window.open(
                    `mailto:${invoice.customer.email}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(emailContent)}`
                  );
                }}
                className="px-4 py-2 rounded-lg bg-blue-600 text-white hover:bg-blue-700 text-sm font-medium"
              >
                Send via Email
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Footer */}
      <footer className="bg-gray-900 text-gray-400 py-8 mt-12">
        <div className="max-w-7xl mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div>
              <h4 className="text-white font-semibold mb-3 flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-yellow-400" />
                InvoiceAI
              </h4>
              <p className="text-sm">
                Create professional invoices in seconds. AI-powered features to make invoicing effortless.
              </p>
            </div>
            <div>
              <h4 className="text-white font-semibold mb-3">Features</h4>
              <ul className="text-sm space-y-2">
                <li>✓ Professional Invoice Templates</li>
                <li>✓ AI-Powered Content Generation</li>
                <li>✓ GST Calculation</li>
                <li>✓ PDF Download & Print</li>
                <li>✓ Email Templates</li>
              </ul>
            </div>
            <div>
              <h4 className="text-white font-semibold mb-3">Partners</h4>
              <ul className="text-sm space-y-2">
                <li className="hover:text-white cursor-pointer transition-colors">🔗 QuickBooks Accounting</li>
                <li className="hover:text-white cursor-pointer transition-colors">🔗 Razorpay Payments</li>
                <li className="hover:text-white cursor-pointer transition-colors">🔗 Zoho Invoice</li>
                <li className="hover:text-white cursor-pointer transition-colors">🔗 Stripe Billing</li>
              </ul>
            </div>
          </div>
          <div className="border-t border-gray-800 mt-8 pt-6 text-center text-xs">
            © 2026 InvoiceAI. All rights reserved. Built with ❤️ for freelancers and small businesses.
          </div>
        </div>
      </footer>
    </div>
  );
}
