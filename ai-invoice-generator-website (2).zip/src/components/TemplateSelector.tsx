import { InvoiceTemplate } from '../types';
import { Crown } from 'lucide-react';

interface Props {
  templates: InvoiceTemplate[];
  selected: string;
  onSelect: (id: string) => void;
}

export default function TemplateSelector({ templates, selected, onSelect }: Props) {
  return (
    <div className="space-y-3">
      <h2 className="text-lg font-semibold text-gray-800 flex items-center gap-2">
        <span>🎨</span> Choose a Template
      </h2>
      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-3">
        {templates.map((template) => (
          <button
            key={template.id}
            onClick={() => onSelect(template.id)}
            className={`relative rounded-xl p-4 text-center transition-all border-2 ${
              selected === template.id
                ? 'border-blue-500 bg-blue-50 shadow-md scale-105'
                : 'border-gray-200 bg-white hover:border-gray-300 hover:shadow-sm'
            }`}
          >
            {template.isPremium && (
              <div className="absolute -top-2 -right-2">
                <span className="flex items-center gap-0.5 bg-gradient-to-r from-yellow-400 to-orange-500 text-white text-[10px] font-bold px-2 py-0.5 rounded-full shadow-sm">
                  <Crown className="w-2.5 h-2.5" />
                  Pro
                </span>
              </div>
            )}
            <div className="text-2xl mb-1">{template.preview}</div>
            <div
              className="text-xs font-medium"
              style={{ color: template.primaryColor }}
            >
              {template.name}
            </div>
          </button>
        ))}
      </div>
    </div>
  );
}
