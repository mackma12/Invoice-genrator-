import { CompanyDetails } from '../types';

interface Props {
  details: CompanyDetails;
  onUpdate: (field: string, value: string) => void;
}

const fields: { key: keyof CompanyDetails; label: string; placeholder: string; type?: string; full?: boolean }[] = [
  { key: 'name', label: 'Company Name', placeholder: 'Your Company Name' },
  { key: 'email', label: 'Email', placeholder: 'billing@company.com', type: 'email' },
  { key: 'phone', label: 'Phone', placeholder: '+91 98765 43210', type: 'tel' },
  { key: 'website', label: 'Website', placeholder: 'www.company.com' },
  { key: 'gstin', label: 'GSTIN', placeholder: '22AAAAA0000A1Z5' },
  { key: 'address', label: 'Address', placeholder: '123 Business Street', full: true },
  { key: 'city', label: 'City', placeholder: 'Mumbai' },
  { key: 'state', label: 'State', placeholder: 'Maharashtra' },
  { key: 'zip', label: 'Zip Code', placeholder: '400001' },
  { key: 'country', label: 'Country', placeholder: 'India' },
];

export default function CompanyDetailsForm({ details, onUpdate }: Props) {
  return (
    <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
      <div className="flex items-center gap-2 mb-6">
        <div className="w-8 h-8 bg-blue-100 rounded-lg flex items-center justify-center text-lg">🏢</div>
        <div>
          <h3 className="text-lg font-semibold text-gray-800">Company Details</h3>
          <p className="text-xs text-gray-500">Your business information</p>
        </div>
      </div>
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        {fields.map(({ key, label, placeholder, type = 'text', full }) => (
          <div key={key} className={full ? 'sm:col-span-2' : ''}>
            <label className="block text-sm font-medium text-gray-700 mb-1">{label}</label>
            <input
              type={type}
              value={details[key]}
              onChange={(e) => onUpdate(key, e.target.value)}
              className="w-full px-4 py-2.5 rounded-lg border border-gray-300 focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all text-sm"
              placeholder={placeholder}
            />
          </div>
        ))}
      </div>
    </div>
  );
}
