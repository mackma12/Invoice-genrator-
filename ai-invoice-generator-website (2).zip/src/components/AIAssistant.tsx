import { InvoiceData } from '../types';
import {
  Wand2,
  Mail,
  FileText,
  AlignLeft,
  Sparkles,
  Copy,
  Check,
  Loader2,
} from 'lucide-react';
import { useState } from 'react';

interface Calculations {
  subtotal: number;
  totalGst: number;
  totalDiscount: number;
  grandTotal: number;
}

interface Props {
  invoice: InvoiceData;
  calculations: Calculations;
  onGenerateEmail: () => void;
  onGenerateTerms: () => void;
  onGenerateNotes: () => void;
  onGenerateDescription: (id: string, description: string) => void;
  aiLoading: boolean;
}

export default function AIAssistant({
  invoice,
  calculations,
  onGenerateEmail,
  onGenerateTerms,
  onGenerateNotes,
  onGenerateDescription,
  aiLoading,
}: Props) {
  const [copiedItems, setCopiedItems] = useState<Set<string>>(new Set());

  const handleCopy = (text: string, key: string) => {
    navigator.clipboard.writeText(text);
    setCopiedItems((prev) => new Set([...prev, key]));
    setTimeout(() => {
      setCopiedItems((prev) => {
        const next = new Set(prev);
        next.delete(key);
        return next;
      });
    }, 2000);
  };

  const aiCards = [
    {
      id: 'email',
      icon: <Mail className="w-5 h-5" />,
      title: 'Email Template',
      description: 'Generate a professional email to send with your invoice.',
      action: onGenerateEmail,
      actionText: 'Generate Email',
      color: 'purple',
    },
    {
      id: 'terms',
      icon: <AlignLeft className="w-5 h-5" />,
      title: 'Payment Terms',
      description: 'AI-generated payment terms for your invoice.',
      action: onGenerateTerms,
      actionText: 'Generate Terms',
      color: 'blue',
    },
    {
      id: 'notes',
      icon: <FileText className="w-5 h-5" />,
      title: 'Invoice Notes',
      description: 'Thank-you messages and important notes for your invoice.',
      action: onGenerateNotes,
      actionText: 'Generate Notes',
      color: 'green',
    },
  ];

  const colorMap: Record<string, { bg: string; text: string; hover: string; border: string; btn: string }> = {
    purple: {
      bg: 'bg-purple-50',
      text: 'text-purple-700',
      hover: 'hover:bg-purple-100',
      border: 'border-purple-200',
      btn: 'bg-purple-600 hover:bg-purple-700',
    },
    blue: {
      bg: 'bg-blue-50',
      text: 'text-blue-700',
      hover: 'hover:bg-blue-100',
      border: 'border-blue-200',
      btn: 'bg-blue-600 hover:bg-blue-700',
    },
    green: {
      bg: 'bg-green-50',
      text: 'text-green-700',
      hover: 'hover:bg-green-100',
      border: 'border-green-200',
      btn: 'bg-green-600 hover:bg-green-700',
    },
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-gradient-to-r from-purple-600 to-indigo-700 rounded-xl p-6 text-white">
        <div className="flex items-center gap-3 mb-3">
          <div className="w-10 h-10 bg-white/20 rounded-xl flex items-center justify-center">
            <Wand2 className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-lg font-bold">AI Assistant</h3>
            <p className="text-purple-200 text-sm">Let AI help you create professional invoices</p>
          </div>
        </div>
        <div className="grid grid-cols-2 gap-3 text-sm mt-4">
          <div className="bg-white/10 rounded-lg p-3">
            <div className="text-purple-200 text-xs">Invoice Total</div>
            <div className="font-bold text-lg">{invoice.currency}{calculations.grandTotal.toFixed(2)}</div>
          </div>
          <div className="bg-white/10 rounded-lg p-3">
            <div className="text-purple-200 text-xs">Items</div>
            <div className="font-bold text-lg">{invoice.items.length}</div>
          </div>
        </div>
      </div>

      {/* AI Feature Cards */}
      {aiCards.map((card) => {
        const colors = colorMap[card.color];
        return (
          <div
            key={card.id}
            className={`bg-white rounded-xl shadow-sm border ${colors.border} overflow-hidden`}
          >
            <div className={`p-5 ${colors.bg}`}>
              <div className="flex items-start justify-between mb-3">
                <div className="flex items-center gap-3">
                  <div className={`w-9 h-9 ${colors.text} bg-white rounded-lg flex items-center justify-center shadow-sm`}>
                    {card.icon}
                  </div>
                  <div>
                    <h4 className="font-semibold text-gray-800">{card.title}</h4>
                    <p className="text-xs text-gray-500">{card.description}</p>
                  </div>
                </div>
              </div>
              <div className="flex gap-2">
                <button
                  onClick={card.action}
                  disabled={aiLoading}
                  className={`flex items-center gap-2 text-white px-4 py-2 rounded-lg text-sm font-medium ${colors.btn} transition-colors disabled:opacity-50`}
                >
                  {aiLoading ? (
                    <Loader2 className="w-4 h-4 animate-spin" />
                  ) : (
                    <Sparkles className="w-4 h-4" />
                  )}
                  {card.actionText}
                </button>
              </div>
              {/* Generated content preview */}
              {card.id === 'terms' && invoice.paymentTerms && (
                <div className={`mt-3 p-3 rounded-lg bg-white border ${colors.border}`}>
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-xs font-medium text-gray-500">Generated Terms</span>
                    <button
                      onClick={() => handleCopy(invoice.paymentTerms, 'terms')}
                      className="text-xs text-gray-400 hover:text-gray-600 flex items-center gap-1"
                    >
                      {copiedItems.has('terms') ? (
                        <><Check className="w-3 h-3 text-green-500" /> Copied!</>
                      ) : (
                        <><Copy className="w-3 h-3" /> Copy</>
                      )}
                    </button>
                  </div>
                  <p className="text-sm text-gray-700">{invoice.paymentTerms}</p>
                </div>
              )}
              {card.id === 'notes' && invoice.notes && (
                <div className={`mt-3 p-3 rounded-lg bg-white border ${colors.border}`}>
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-xs font-medium text-gray-500">Generated Notes</span>
                    <button
                      onClick={() => handleCopy(invoice.notes, 'notes')}
                      className="text-xs text-gray-400 hover:text-gray-600 flex items-center gap-1"
                    >
                      {copiedItems.has('notes') ? (
                        <><Check className="w-3 h-3 text-green-500" /> Copied!</>
                      ) : (
                        <><Copy className="w-3 h-3" /> Copy</>
                      )}
                    </button>
                  </div>
                  <p className="text-sm text-gray-700">{invoice.notes}</p>
                </div>
              )}
            </div>
          </div>
        );
      })}

      {/* Item Description Generator */}
      <div className="bg-white rounded-xl shadow-sm border border-orange-200 overflow-hidden">
        <div className="p-5 bg-orange-50">
          <div className="flex items-center gap-3 mb-3">
            <div className="w-9 h-9 bg-orange-600 text-white rounded-lg flex items-center justify-center shadow-sm">
              <Sparkles className="w-5 h-5" />
            </div>
            <div>
              <h4 className="font-semibold text-gray-800">Item Descriptions</h4>
              <p className="text-xs text-gray-500">Click the sparkle icon next to any item description to generate AI content</p>
            </div>
          </div>
          <div className="space-y-2">
            {invoice.items.map((item, i) => (
              <div key={item.id} className="flex items-center gap-2 bg-white rounded-lg p-3 border border-gray-100">
                <span className="text-sm text-gray-400 w-6">{i + 1}.</span>
                <span className="text-sm text-gray-700 flex-1 truncate">
                  {item.description || 'Empty description'}
                </span>
                <button
                  onClick={() => onGenerateDescription(item.id, item.description || 'service')}
                  disabled={aiLoading || item.aiGenerating || !item.description}
                  className="text-purple-500 hover:text-purple-700 disabled:opacity-30 p-1 rounded hover:bg-purple-50 transition-colors"
                >
                  {item.aiGenerating ? (
                    <Loader2 className="w-4 h-4 animate-spin" />
                  ) : (
                    <Sparkles className="w-4 h-4" />
                  )}
                </button>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Tips */}
      <div className="bg-gradient-to-r from-blue-50 to-indigo-50 rounded-xl p-5 border border-blue-200">
        <h4 className="font-semibold text-gray-800 mb-3 flex items-center gap-2">
          💡 Pro Tips
        </h4>
        <ul className="space-y-2 text-sm text-gray-600">
          <li className="flex items-start gap-2">
            <span className="text-blue-500 mt-0.5">•</span>
            <span>Fill in your company details once — they'll be saved for future invoices</span>
          </li>
          <li className="flex items-start gap-2">
            <span className="text-blue-500 mt-0.5">•</span>
            <span>Use AI to generate professional descriptions by typing a keyword like "web development" or "design"</span>
          </li>
          <li className="flex items-start gap-2">
            <span className="text-blue-500 mt-0.5">•</span>
            <span>Generate an email template to quickly send your invoice to clients</span>
          </li>
          <li className="flex items-start gap-2">
            <span className="text-blue-500 mt-0.5">•</span>
            <span>Download as PDF and share via email or messaging apps</span>
          </li>
        </ul>
      </div>

      {/* API Integration Notice */}
      <div className="bg-yellow-50 rounded-xl p-5 border border-yellow-200">
        <h4 className="font-semibold text-gray-800 mb-2 flex items-center gap-2">
          🔧 API Integration
        </h4>
        <p className="text-sm text-gray-600 mb-3">
          This tool currently uses smart templates for AI generation. For advanced AI capabilities,
          integrate OpenAI or Gemini API for real-time content generation.
        </p>
        <div className="bg-white rounded-lg p-3 border border-yellow-200">
          <code className="text-xs text-gray-700">
            // Add your API key in aiGenerator.ts<br/>
            OpenAI: gpt-4o-mini<br/>
            Gemini: gemini-pro
          </code>
        </div>
      </div>
    </div>
  );
}
