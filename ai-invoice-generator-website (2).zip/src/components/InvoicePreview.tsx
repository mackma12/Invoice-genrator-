import { InvoiceData, templates } from '../types';

interface Calculations {
  subtotal: number;
  totalGst: number;
  totalDiscount: number;
  grandTotal: number;
}

interface Props {
  invoice: InvoiceData;
  templateId: string;
  calculations: Calculations;
}

export default function InvoicePreview({ invoice, templateId, calculations }: Props) {
  const template = templates.find((t) => t.id === templateId) || templates[0];
  const primaryColor = template.primaryColor;

  return (
    <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
      <div className="bg-gray-50 border-b px-4 py-2 flex items-center justify-between">
        <span className="text-sm font-medium text-gray-600">Invoice Preview</span>
        <div className="flex items-center gap-2">
          <div className="w-3 h-3 rounded-full" style={{ backgroundColor: primaryColor }}></div>
          <span className="text-xs text-gray-500">{template.name}</span>
        </div>
      </div>

      <div className="p-6">
        {/* Invoice Header */}
        <div
          className="rounded-t-xl p-6 text-white"
          style={{ backgroundColor: primaryColor }}
        >
          <div className="flex justify-between items-start">
            <div>
              <h2 className="text-2xl font-bold">{invoice.company.name || 'Your Company'}</h2>
              {invoice.company.email && (
                <p className="text-sm opacity-80 mt-1">{invoice.company.email}</p>
              )}
              {invoice.company.phone && (
                <p className="text-sm opacity-80">{invoice.company.phone}</p>
              )}
            </div>
            <div className="text-right">
              <h3 className="text-3xl font-bold">INVOICE</h3>
              <p className="text-sm opacity-80 mt-1">#{invoice.invoiceNumber}</p>
            </div>
          </div>
          <div className="flex gap-6 mt-4 text-sm opacity-90">
            <span>Date: {invoice.invoiceDate}</span>
            <span>Due: {invoice.dueDate}</span>
          </div>
        </div>

        {/* From / To */}
        <div className="grid grid-cols-2 gap-6 p-6 pb-4">
          <div>
            <h4 className="text-xs font-semibold text-gray-400 uppercase tracking-wider mb-2">From</h4>
            <p className="font-semibold text-gray-800">{invoice.company.name || '—'}</p>
            {invoice.company.gstin && <p className="text-sm text-gray-600">GSTIN: {invoice.company.gstin}</p>}
            {invoice.company.address && <p className="text-sm text-gray-600">{invoice.company.address}</p>}
            {invoice.company.city && (
              <p className="text-sm text-gray-600">
                {invoice.company.city}, {invoice.company.state} {invoice.company.zip}
              </p>
            )}
          </div>
          <div>
            <h4 className="text-xs font-semibold text-gray-400 uppercase tracking-wider mb-2">Bill To</h4>
            <p className="font-semibold text-gray-800">{invoice.customer.name || '—'}</p>
            {invoice.customer.gstin && <p className="text-sm text-gray-600">GSTIN: {invoice.customer.gstin}</p>}
            {invoice.customer.address && <p className="text-sm text-gray-600">{invoice.customer.address}</p>}
            {invoice.customer.city && (
              <p className="text-sm text-gray-600">
                {invoice.customer.city}, {invoice.customer.state} {invoice.customer.zip}
              </p>
            )}
          </div>
        </div>

        {/* Items Table */}
        <div className="px-6 pb-4">
          <table className="w-full text-sm">
            <thead>
              <tr className="text-left" style={{ color: primaryColor }}>
                <th className="pb-2 font-semibold border-b">#</th>
                <th className="pb-2 font-semibold border-b">Description</th>
                <th className="pb-2 font-semibold border-b text-center">Qty</th>
                <th className="pb-2 font-semibold border-b text-right">Rate</th>
                <th className="pb-2 font-semibold border-b text-center">GST</th>
                <th className="pb-2 font-semibold border-b text-right">Amount</th>
              </tr>
            </thead>
            <tbody>
              {invoice.items.map((item, i) => {
                const amount = item.quantity * item.rate * (1 - item.discount / 100) * (1 + item.gst / 100);
                return (
                  <tr key={item.id} className="border-b border-gray-100">
                    <td className="py-2 text-gray-500">{i + 1}</td>
                    <td className="py-2 text-gray-800">{item.description || 'Item'}</td>
                    <td className="py-2 text-center text-gray-600">{item.quantity}</td>
                    <td className="py-2 text-right text-gray-600">{invoice.currency}{item.rate.toFixed(2)}</td>
                    <td className="py-2 text-center text-gray-600">{item.gst}%</td>
                    <td className="py-2 text-right font-medium text-gray-800">{invoice.currency}{amount.toFixed(2)}</td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>

        {/* Totals */}
        <div className="px-6 pb-4">
          <div className="flex justify-end">
            <div className="w-64 space-y-2">
              <div className="flex justify-between text-sm text-gray-600">
                <span>Subtotal</span>
                <span>{invoice.currency}{calculations.subtotal.toFixed(2)}</span>
              </div>
              {calculations.totalDiscount > 0 && (
                <div className="flex justify-between text-sm text-red-500">
                  <span>Discount</span>
                  <span>-{invoice.currency}{calculations.totalDiscount.toFixed(2)}</span>
                </div>
              )}
              <div className="flex justify-between text-sm text-gray-600">
                <span>GST</span>
                <span>{invoice.currency}{calculations.totalGst.toFixed(2)}</span>
              </div>
              <div
                className="flex justify-between text-lg font-bold pt-2 border-t"
                style={{ color: primaryColor }}
              >
                <span>Total</span>
                <span>{invoice.currency}{calculations.grandTotal.toFixed(2)}</span>
              </div>
            </div>
          </div>
        </div>

        {/* Bank Details */}
        {(invoice.bankName || invoice.accountNumber) && (
          <div className="px-6 pb-4 pt-4 border-t">
            <h4 className="text-xs font-semibold text-gray-400 uppercase tracking-wider mb-2">Payment Details</h4>
            {invoice.bankName && <p className="text-sm text-gray-600">Bank: {invoice.bankName}</p>}
            {invoice.accountNumber && <p className="text-sm text-gray-600">Account: {invoice.accountNumber}</p>}
            {invoice.ifscCode && <p className="text-sm text-gray-600">IFSC: {invoice.ifscCode}</p>}
          </div>
        )}

        {/* Notes & Terms */}
        {(invoice.notes || invoice.paymentTerms) && (
          <div className="px-6 pb-6 pt-2 border-t space-y-3">
            {invoice.notes && (
              <div>
                <h4 className="text-xs font-semibold text-gray-400 uppercase tracking-wider mb-1">Notes</h4>
                <p className="text-sm text-gray-600">{invoice.notes}</p>
              </div>
            )}
            {invoice.paymentTerms && (
              <div>
                <h4 className="text-xs font-semibold text-gray-400 uppercase tracking-wider mb-1">Payment Terms</h4>
                <p className="text-sm text-gray-600">{invoice.paymentTerms}</p>
              </div>
            )}
          </div>
        )}

        {/* Signature */}
        {invoice.signature && (
          <div className="px-6 pb-6 text-right">
            <p className="font-bold text-gray-800 text-sm">{invoice.signature}</p>
            <div className="border-t border-gray-300 w-48 ml-auto mt-1"></div>
            <p className="text-xs text-gray-500">Authorized Signatory</p>
          </div>
        )}

        {/* Footer */}
        <div className="bg-gray-50 px-6 py-3 text-center">
          <p className="text-xs text-gray-400">
            Thank you for your business! • {invoice.company.name || 'InvoiceAI'}
          </p>
        </div>
      </div>
    </div>
  );
}
