export default function AdBanner({ variant = 'top' }: { variant?: 'top' | 'sidebar' }) {
  if (variant === 'sidebar') {
    return (
      <div className="bg-gradient-to-b from-gray-100 to-gray-50 rounded-xl border-2 border-dashed border-gray-300 p-6 text-center">
        <div className="text-xs text-gray-400 uppercase tracking-wider mb-2">Advertisement</div>
        <div className="w-full h-48 bg-gray-200 rounded-lg flex items-center justify-center">
          <div className="text-center">
            <div className="text-3xl mb-2">📢</div>
            <div className="text-sm text-gray-500 font-medium">Ad Space</div>
            <div className="text-xs text-gray-400 mt-1">300 × 250</div>
          </div>
        </div>
        <div className="mt-3 text-xs text-gray-400">
          Contact us for advertising
        </div>
      </div>
    );
  }

  return (
    <div className="bg-gradient-to-r from-gray-100 via-gray-50 to-gray-100 border-b border-gray-200">
      <div className="max-w-7xl mx-auto px-4 py-3 flex items-center justify-center gap-6">
        <div className="text-xs text-gray-400 uppercase tracking-wider">Sponsored</div>
        <div className="flex gap-4">
          <div className="h-8 w-32 bg-gray-200 rounded-md flex items-center justify-center">
            <span className="text-xs text-gray-400">Ad 728×90</span>
          </div>
          <div className="h-8 w-32 bg-gray-200 rounded-md flex items-center justify-center">
            <span className="text-xs text-gray-400">Ad 728×90</span>
          </div>
        </div>
      </div>
    </div>
  );
}
