import { Sparkles, FileText } from 'lucide-react';

export default function Header() {
  return (
    <header className="bg-white border-b border-gray-200 sticky top-0 z-40">
      <div className="max-w-7xl mx-auto px-4 py-3 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="w-9 h-9 bg-gradient-to-br from-blue-600 to-indigo-700 rounded-lg flex items-center justify-center">
            <FileText className="w-5 h-5 text-white" />
          </div>
          <div>
            <span className="text-xl font-bold text-gray-800">Invoice</span>
            <span className="text-xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">AI</span>
          </div>
        </div>
        <div className="flex items-center gap-3">
          <span className="hidden sm:inline-flex items-center gap-1 text-xs bg-purple-100 text-purple-700 px-3 py-1.5 rounded-full font-medium">
            <Sparkles className="w-3 h-3" />
            AI Powered
          </span>
          <a
            href="#templates"
            className="text-sm text-gray-600 hover:text-blue-600 transition-colors hidden md:inline-block"
          >
            Templates
          </a>
          <a
            href="#features"
            className="text-sm text-gray-600 hover:text-blue-600 transition-colors hidden md:inline-block"
          >
            Features
          </a>
        </div>
      </div>
    </header>
  );
}
