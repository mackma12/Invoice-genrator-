import { LineItem } from '../types';
import { Trash2, Plus, Sparkles, Loader2 } from 'lucide-react';

interface Props {
  items: LineItem[];
  currency: string;
  onUpdate: (id: string, field: string, value: string | number | boolean) => void;
  onAdd: () => void;
  onRemove: (id: string) => void;
  onAiGenerate: (id: string, description: string) => void;
  aiLoading: boolean;
}

export default function LineItemsTable({ items, currency, onUpdate, onAdd, onRemove, onAiGenerate, aiLoading }: Props) {
  return (
    <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 bg-orange-100 rounded-lg flex items-center justify-center text-lg">📦</div>
          <div>
            <h3 className="text-lg font-semibold text-gray-800">Line Items</h3>
            <p className="text-xs text-gray-500">Products and services</p>
          </div>
        </div>
        <button
          onClick={onAdd}
          className="flex items-center gap-1 bg-blue-600 text-white px-3 py-1.5 rounded-lg text-sm hover:bg-blue-700 transition-colors"
        >
          <Plus className="w-4 h-4" />
          Add Item
        </button>
      </div>

      {/* Desktop Table */}
      <div className="hidden md:block overflow-x-auto">
        <table className="w-full text-sm">
          <thead>
            <tr className="text-left text-gray-500 border-b border-gray-200">
              <th className="pb-3 font-medium w-10">#</th>
              <th className="pb-3 font-medium">Description</th>
              <th className="pb-3 font-medium w-16 text-center">Qty</th>
              <th className="pb-3 font-medium w-28 text-right">Rate</th>
              <th className="pb-3 font-medium w-16 text-center">GST%</th>
              <th className="pb-3 font-medium w-16 text-center">Disc%</th>
              <th className="pb-3 font-medium w-28 text-right">Amount</th>
              <th className="pb-3 font-medium w-10"></th>
            </tr>
          </thead>
          <tbody>
            {items.map((item, index) => {
              const itemTotal = item.quantity * item.rate * (1 - item.discount / 100) * (1 + item.gst / 100);
              return (
                <tr key={item.id} className="border-b border-gray-100 hover:bg-gray-50">
                  <td className="py-3 text-gray-400">{index + 1}</td>
                  <td className="py-3">
                    <div className="relative">
                      <input
                        type="text"
                        value={item.description}
                        onChange={(e) => onUpdate(item.id, 'description', e.target.value)}
                        className="w-full px-3 py-2 rounded-lg border border-gray-300 focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all text-sm"
                        placeholder="Item description"
                      />
                      <button
                        onClick={() => onAiGenerate(item.id, item.description)}
                        disabled={aiLoading || item.aiGenerating || !item.description}
                        className="absolute right-2 top-1/2 -translate-y-1/2 text-purple-500 hover:text-purple-700 disabled:opacity-30 transition-colors"
                        title="AI generate description"
                      >
                        {item.aiGenerating ? (
                          <Loader2 className="w-4 h-4 animate-spin" />
                        ) : (
                          <Sparkles className="w-4 h-4" />
                        )}
                      </button>
                    </div>
                  </td>
                  <td className="py-3">
                    <input
                      type="number"
                      value={item.quantity}
                      onChange={(e) => onUpdate(item.id, 'quantity', Number(e.target.value))}
                      className="w-full px-2 py-2 rounded-lg border border-gray-300 focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-center text-sm"
                      min="0"
                    />
                  </td>
                  <td className="py-3">
                    <input
                      type="number"
                      value={item.rate}
                      onChange={(e) => onUpdate(item.id, 'rate', Number(e.target.value))}
                      className="w-full px-2 py-2 rounded-lg border border-gray-300 focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-right text-sm"
                      min="0"
                      step="0.01"
                    />
                  </td>
                  <td className="py-3">
                    <select
                      value={item.gst}
                      onChange={(e) => onUpdate(item.id, 'gst', Number(e.target.value))}
                      className="w-full px-1 py-2 rounded-lg border border-gray-300 focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-center text-sm"
                    >
                      <option value={0}>0%</option>
                      <option value={5}>5%</option>
                      <option value={12}>12%</option>
                      <option value={18}>18%</option>
                      <option value={28}>28%</option>
                    </select>
                  </td>
                  <td className="py-3">
                    <input
                      type="number"
                      value={item.discount}
                      onChange={(e) => onUpdate(item.id, 'discount', Number(e.target.value))}
                      className="w-full px-2 py-2 rounded-lg border border-gray-300 focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-center text-sm"
                      min="0"
                      max="100"
                    />
                  </td>
                  <td className="py-3 text-right font-medium text-gray-800">
                    {currency}{itemTotal.toFixed(2)}
                  </td>
                  <td className="py-3 text-center">
                    <button
                      onClick={() => onRemove(item.id)}
                      className="text-red-400 hover:text-red-600 transition-colors p-1"
                      disabled={items.length === 1}
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      {/* Mobile Cards */}
      <div className="md:hidden space-y-4">
        {items.map((item, index) => {
          const itemTotal = item.quantity * item.rate * (1 - item.discount / 100) * (1 + item.gst / 100);
          return (
            <div key={item.id} className="border border-gray-200 rounded-lg p-4 space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium text-gray-500">Item #{index + 1}</span>
                <button
                  onClick={() => onRemove(item.id)}
                  className="text-red-400 hover:text-red-600 p-1"
                  disabled={items.length === 1}
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
              <div className="relative">
                <input
                  type="text"
                  value={item.description}
                  onChange={(e) => onUpdate(item.id, 'description', e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-gray-300 focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-sm"
                  placeholder="Item description"
                />
                <button
                  onClick={() => onAiGenerate(item.id, item.description)}
                  disabled={aiLoading || item.aiGenerating || !item.description}
                  className="absolute right-2 top-1/2 -translate-y-1/2 text-purple-500 hover:text-purple-700 disabled:opacity-30 transition-colors"
                >
                  {item.aiGenerating ? (
                    <Loader2 className="w-4 h-4 animate-spin" />
                  ) : (
                    <Sparkles className="w-4 h-4" />
                  )}
                </button>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs text-gray-500">Quantity</label>
                  <input
                    type="number"
                    value={item.quantity}
                    onChange={(e) => onUpdate(item.id, 'quantity', Number(e.target.value))}
                    className="w-full px-3 py-2 rounded-lg border border-gray-300 text-sm"
                    min="0"
                  />
                </div>
                <div>
                  <label className="text-xs text-gray-500">Rate</label>
                  <input
                    type="number"
                    value={item.rate}
                    onChange={(e) => onUpdate(item.id, 'rate', Number(e.target.value))}
                    className="w-full px-3 py-2 rounded-lg border border-gray-300 text-sm"
                    min="0"
                    step="0.01"
                  />
                </div>
                <div>
                  <label className="text-xs text-gray-500">GST %</label>
                  <select
                    value={item.gst}
                    onChange={(e) => onUpdate(item.id, 'gst', Number(e.target.value))}
                    className="w-full px-3 py-2 rounded-lg border border-gray-300 text-sm"
                  >
                    <option value={0}>0%</option>
                    <option value={5}>5%</option>
                    <option value={12}>12%</option>
                    <option value={18}>18%</option>
                    <option value={28}>28%</option>
                  </select>
                </div>
                <div>
                  <label className="text-xs text-gray-500">Discount %</label>
                  <input
                    type="number"
                    value={item.discount}
                    onChange={(e) => onUpdate(item.id, 'discount', Number(e.target.value))}
                    className="w-full px-3 py-2 rounded-lg border border-gray-300 text-sm"
                    min="0"
                    max="100"
                  />
                </div>
              </div>
              <div className="text-right font-semibold text-gray-800 pt-2 border-t">
                {currency}{itemTotal.toFixed(2)}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
