export interface CompanyDetails {
  name: string;
  email: string;
  phone: string;
  address: string;
  city: string;
  state: string;
  zip: string;
  country: string;
  gstin: string;
  website: string;
  logo: string;
}

export interface CustomerDetails {
  name: string;
  email: string;
  phone: string;
  address: string;
  city: string;
  state: string;
  zip: string;
  country: string;
  gstin: string;
}

export interface LineItem {
  id: string;
  description: string;
  quantity: number;
  rate: number;
  gst: number;
  discount: number;
  aiGenerating: boolean;
}

export interface InvoiceData {
  invoiceNumber: string;
  invoiceDate: string;
  dueDate: string;
  company: CompanyDetails;
  customer: CustomerDetails;
  items: LineItem[];
  notes: string;
  paymentTerms: string;
  bankName: string;
  accountNumber: string;
  ifscCode: string;
  currency: string;
  signature: string;
}

export interface InvoiceTemplate {
  id: string;
  name: string;
  preview: string;
  primaryColor: string;
  secondaryColor: string;
  fontFamily: string;
  isPremium: boolean;
}

export const defaultCompany: CompanyDetails = {
  name: '',
  email: '',
  phone: '',
  address: '',
  city: '',
  state: '',
  zip: '',
  country: 'India',
  gstin: '',
  website: '',
  logo: '',
};

export const defaultCustomer: CustomerDetails = {
  name: '',
  email: '',
  phone: '',
  address: '',
  city: '',
  state: '',
  zip: '',
  country: 'India',
  gstin: '',
};

export const defaultInvoice: InvoiceData = {
  invoiceNumber: `INV-${Date.now().toString().slice(-6)}`,
  invoiceDate: new Date().toISOString().split('T')[0],
  dueDate: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
  company: { ...defaultCompany },
  customer: { ...defaultCustomer },
  items: [
    { id: '1', description: '', quantity: 1, rate: 0, gst: 18, discount: 0, aiGenerating: false },
  ],
  notes: '',
  paymentTerms: '',
  bankName: '',
  accountNumber: '',
  ifscCode: '',
  currency: '₹',
  signature: '',
};

export const templates: InvoiceTemplate[] = [
  {
    id: 'modern',
    name: 'Modern Blue',
    preview: '📘',
    primaryColor: '#2563EB',
    secondaryColor: '#1E40AF',
    fontFamily: 'Inter, sans-serif',
    isPremium: false,
  },
  {
    id: 'elegant',
    name: 'Elegant Green',
    preview: '📗',
    primaryColor: '#059669',
    secondaryColor: '#047857',
    fontFamily: 'Inter, sans-serif',
    isPremium: false,
  },
  {
    id: 'minimal',
    name: 'Minimal Gray',
    preview: '📙',
    primaryColor: '#6B7280',
    secondaryColor: '#4B5563',
    fontFamily: 'Inter, sans-serif',
    isPremium: false,
  },
  {
    id: 'corporate',
    name: 'Corporate Navy',
    preview: '📕',
    primaryColor: '#1E3A5F',
    secondaryColor: '#152A45',
    fontFamily: 'Inter, sans-serif',
    isPremium: false,
  },
  {
    id: 'creative',
    name: 'Creative Purple',
    preview: '📓',
    primaryColor: '#7C3AED',
    secondaryColor: '#6D28D9',
    fontFamily: 'Inter, sans-serif',
    isPremium: true,
  },
  {
    id: 'warm',
    name: 'Warm Orange',
    preview: '📒',
    primaryColor: '#EA580C',
    secondaryColor: '#C2410C',
    fontFamily: 'Inter, sans-serif',
    isPremium: true,
  },
];
