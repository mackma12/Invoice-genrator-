// AI-powered content generator using smart templates
// Can be extended with real OpenAI/Gemini API by setting API_KEY

export interface AIConfig {
  openaiApiKey?: string;
  geminiApiKey?: string;
  provider: 'template' | 'openai' | 'gemini';
}

const itemDescriptions: Record<string, string[]> = {
  'web development': [
    'Custom responsive website development with modern UI/UX design principles, cross-browser compatibility, and performance optimization',
    'Full-stack web application development using React, Node.js, and MongoDB with RESTful API integration',
    'E-commerce website development with payment gateway integration, inventory management, and order tracking',
    'Progressive web app (PWA) development with offline support, push notifications, and native-like experience',
  ],
  'website': [
    'Professional website design and development with responsive layout and SEO optimization',
    'Custom CMS-based website with content management, user authentication, and admin dashboard',
    'Landing page design and development optimized for conversions and lead generation',
    'Corporate website with company portfolio, team profiles, and contact management system',
  ],
  'mobile app': [
    'Cross-platform mobile application development using React Native with native performance',
    'iOS and Android app development with intuitive UI, push notifications, and cloud sync',
    'Mobile app UI/UX design and prototyping with user testing and iterative improvements',
    'Mobile app maintenance, bug fixes, performance optimization, and feature updates',
  ],
  'design': [
    'Professional logo and brand identity design package with multiple concepts and revisions',
    'UI/UX design for web and mobile applications including wireframes, prototypes, and design system',
    'Marketing collateral design including brochures, flyers, business cards, and presentations',
    'Social media graphics and content design package for all major platforms',
  ],
  'consulting': [
    'Strategic business consulting with market analysis, competitive research, and growth planning',
    'Technical consulting for system architecture, technology stack selection, and scalability planning',
    'Digital transformation consulting with implementation roadmap and change management strategy',
    'IT infrastructure assessment with optimization recommendations and cost analysis',
  ],
  'seo': [
    'Comprehensive SEO audit and optimization strategy with technical analysis and keyword research',
    'On-page and off-page SEO optimization including meta tags, content optimization, and link building',
    'Keyword research and competitive analysis report with actionable recommendations',
    'Technical SEO implementation with site speed optimization, schema markup, and crawl error fixes',
  ],
  'content writing': [
    'Professional blog article writing (1000+ words) with SEO optimization and keyword integration',
    'Website copywriting for landing pages, product descriptions, and service pages',
    'Social media content creation with editorial calendar, scheduling, and engagement strategy',
    'Email marketing campaign content creation with A/B testing and performance tracking',
  ],
  'maintenance': [
    'Monthly website maintenance including security updates, backups, and performance monitoring',
    'Server management with uptime monitoring, SSL certificate management, and load optimization',
    'Bug fixes, security patches, and minor feature updates with priority support',
    'Regular content updates, CMS management, and database optimization',
  ],
  'marketing': [
    'Digital marketing campaign management with multi-channel strategy and analytics reporting',
    'Google Ads and social media advertising management with budget optimization and ROI tracking',
    'Email marketing automation setup with drip campaigns, segmentation, and A/B testing',
    'Brand awareness and lead generation strategy with content marketing and social media presence',
  ],
  'accounting': [
    'Monthly bookkeeping and financial record management with reconciliation and reporting',
    'Tax preparation and filing services for individuals and businesses with compliance assurance',
    'Financial reporting and analysis for business decisions with forecasting and budgeting',
    'Payroll processing and employee benefit management with statutory compliance',
  ],
  'graphic design': [
    'Brand identity package including logo design, color palette, typography, and brand guidelines',
    'Infographic design for presentations, reports, and social media with data visualization',
    'Packaging design and print-ready artwork with 3D mockups and production specifications',
    'Custom illustration and artwork for digital media, websites, and print publications',
  ],
  'logo': [
    'Professional logo design with 3 unique concepts, unlimited revisions, and brand guidelines',
    'Minimalist logo design with versatile applications for web, print, and merchandise',
    'Logo redesign and brand refresh with modern aesthetics while maintaining brand recognition',
    'Animated logo creation for digital platforms, presentations, and video content',
  ],
  'video': [
    'Professional video editing with color grading, transitions, motion graphics, and sound design',
    'Explainer video production with scriptwriting, storyboarding, animation, and voiceover',
    'Social media video content creation optimized for Instagram Reels, YouTube Shorts, and TikTok',
    'Corporate video production including interviews, product demos, and company presentations',
  ],
  'photography': [
    'Professional product photography with studio lighting, retouching, and e-commerce optimization',
    'Corporate event photography with candid and posed shots, editing, and online gallery delivery',
    'Real estate photography with HDR processing, virtual tours, and drone aerial shots',
    'Portrait and headshot photography with professional lighting, retouching, and print-ready files',
  ],
  'support': [
    'Technical support services with ticket management, live chat, and priority escalation',
    'Customer support management with multi-channel coverage and satisfaction tracking',
    'IT helpdesk services with remote troubleshooting, on-site support, and knowledge base',
    '24/7 monitoring and support with SLA-based response times and dedicated account management',
  ],
  'training': [
    'Corporate training program development with customized curriculum and assessment tools',
    'Online course creation with video lessons, quizzes, and interactive learning materials',
    'Workshop facilitation with hands-on exercises, case studies, and certification program',
    'One-on-one coaching and mentoring sessions with personalized learning plans',
  ],
  'api': [
    'RESTful API development with authentication, rate limiting, documentation, and testing',
    'API integration and middleware development connecting third-party services and databases',
    'GraphQL API implementation with schema design, resolvers, and subscription support',
    'API performance optimization with caching, pagination, and response time improvements',
  ],
  'database': [
    'Database design and architecture with normalization, indexing, and query optimization',
    'Database migration and data transfer with zero downtime and data integrity verification',
    'Database performance tuning with query optimization, indexing strategy, and replication',
    'Data warehousing and ETL pipeline development for analytics and reporting',
  ],
  'testing': [
    'Comprehensive software testing with unit tests, integration tests, and end-to-end testing',
    'Quality assurance and bug tracking with automated test suites and CI/CD integration',
    'Performance testing and load testing with bottleneck identification and optimization',
    'Security testing and vulnerability assessment with penetration testing and compliance audit',
  ],
  'hosting': [
    'Cloud hosting setup and configuration with AWS, Azure, or Google Cloud Platform',
    'VPS management with server hardening, monitoring, automated backups, and disaster recovery',
    'CDN configuration and optimization for global content delivery and reduced latency',
    'Domain management and DNS configuration with SSL certificates and email setup',
  ],
  'social media': [
    'Social media management with content creation, scheduling, engagement, and analytics',
    'Social media advertising campaign management with targeting, budgeting, and ROI optimization',
    'Influencer marketing strategy with identification, outreach, and campaign management',
    'Community management with response management, moderation, and engagement growth',
  ],
};

const paymentTerms = [
  'Payment is due within 15 days of the invoice date. Late payments may incur a 2% monthly interest charge.',
  'Full payment is due upon receipt of this invoice. Please process payment via bank transfer or UPI.',
  '50% advance payment required before project commencement. Balance due upon successful completion and delivery.',
  'Net 30 — Payment is due within 30 days of the invoice date. A late fee of 1.5% per month will be applied to overdue balances.',
  'Net 15 with 2% early payment discount if paid within 7 days of the invoice date.',
  'Milestone-based payment: 30% upon project initiation, 40% at mid-project review, 30% upon final delivery and acceptance.',
  'Payments accepted via bank transfer, UPI, credit/debit card, or PayPal. Processing time is 3-5 business days.',
  'Payment is due upon completion and approval of deliverables. Invoice must be settled before final handover.',
  'Monthly retainer billing — payment due on the 1st of each month for services rendered in the preceding month.',
  'Split payment plan: 25% upfront, 25% at 25% completion, 25% at 75% completion, 25% upon final delivery.',
];

const invoiceNotes = [
  'Thank you for your business! We truly value our partnership and look forward to working with you again. If you have any questions about this invoice, please don\'t hesitate to reach out.',
  'Please reference the invoice number when making payment. For any queries or discrepancies, contact us within 7 days of receiving this invoice.',
  'This invoice is generated electronically and is valid without a physical signature. Payment can be made via bank transfer to the details provided above.',
  'All amounts are inclusive of applicable taxes as per government regulations. GST is calculated at the applicable rate for the goods/services provided.',
  'We appreciate your prompt payment. For your convenience, multiple payment options are available. Please contact us if you need any assistance with the payment process.',
  'Thank you for choosing our services. We are committed to delivering excellence in every project. Your satisfaction is our top priority.',
  'Please ensure timely payment to avoid any service interruptions. If you are experiencing any issues with payment, please contact our accounts team immediately.',
  'This invoice reflects the services/products delivered as per our agreement. Any additional work or changes will be invoiced separately with prior approval.',
];

const emailTemplates: Record<string, (name: string, amount: string, invoiceNum: string, companyName: string) => string> = {
  professional: (name, amount, invoiceNum, companyName) =>
    `Subject: Invoice #${invoiceNum} from ${companyName}\n\nDear ${name},\n\nI hope this email finds you well.\n\nPlease find attached Invoice #${invoiceNum} for the amount of ${amount}. The payment is due as per the terms mentioned in the invoice.\n\nInvoice Details:\n- Invoice Number: ${invoiceNum}\n- Amount Due: ${amount}\n\nShould you have any questions or require any clarifications regarding this invoice, please don't hesitate to reach out to us.\n\nWe value your business and appreciate your prompt attention to this matter.\n\nThank you for your continued partnership.\n\nBest regards,\nAccounts Team\n${companyName}`,

  friendly: (name, amount, invoiceNum, companyName) =>
    `Subject: Here's your invoice #${invoiceNum} from ${companyName} 🎉\n\nHi ${name},\n\nHope you're having a great week!\n\nI'm sending over Invoice #${invoiceNum} for ${amount}. Everything looks good on our end, and we truly enjoyed working on this project with you.\n\nWhen you get a chance, please review the attached invoice and process the payment as per the terms mentioned.\n\nIf you need anything else or have any questions at all, just hit reply — I'm always happy to help!\n\nThanks again for being an awesome client. Looking forward to our next collaboration! 🚀\n\nWarm regards,\nYour Friendly Team\n${companyName}`,

  formal: (name, amount, invoiceNum, companyName) =>
    `Subject: Invoice Submission — Reference #${invoiceNum}\n\nDear ${name},\n\nWe hereby submit Invoice #${invoiceNum} for your kind attention and processing.\n\nInvoice Details:\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\nInvoice Number: ${invoiceNum}\nInvoice Amount: ${amount}\nPayment Due Date: As specified in the invoice\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n\nWe kindly request you to process the payment at your earliest convenience in accordance with the payment terms outlined in the invoice.\n\nShould you require any additional documentation, clarification, or supporting evidence for this invoice, please do not hesitate to contact our accounts department.\n\nWe value your business and look forward to our continued association.\n\nYours sincerely,\nAccounts Department\n${companyName}`,

  reminder: (name, amount, invoiceNum, companyName) =>
    `Subject: Payment Reminder — Invoice #${invoiceNum} (Overdue)\n\nDear ${name},\n\nThis is a friendly reminder that Invoice #${invoiceNum} for ${amount} is currently pending payment.\n\nWe understand that oversights happen, and we kindly request you to process the payment at your earliest convenience.\n\nInvoice Details:\n- Invoice Number: ${invoiceNum}\n- Amount Due: ${amount}\n- Status: Pending\n\nIf the payment has already been initiated, please disregard this reminder and accept our thanks. If you have any questions, concerns, or require a payment extension, please reach out to us and we'll be happy to discuss.\n\nThank you for your prompt attention to this matter.\n\nBest regards,\nAccounts Team\n${companyName}`,
};

export async function generateItemDescription(
  itemDescription: string,
  _config?: AIConfig
): Promise<string> {
  if (!itemDescription || !itemDescription.trim()) {
    return 'Professional service delivered with quality assurance and timely completion';
  }

  const key = Object.keys(itemDescriptions).find((k) =>
    itemDescription.toLowerCase().includes(k)
  );

  if (key) {
    const descriptions = itemDescriptions[key];
    return descriptions[Math.floor(Math.random() * descriptions.length)];
  }

  // Generate a professional description from the input
  const prefixes = [
    'Professional',
    'High-quality',
    'Custom',
    'Comprehensive',
    'Premium',
    'Expert',
    'Advanced',
  ];
  const suffixes = [
    'with dedicated support and quality assurance',
    'delivered on schedule with full documentation',
    'meeting industry standards and best practices',
    'tailored to your specific requirements',
    'with ongoing maintenance and support included',
    'with detailed reporting and analytics',
    'with performance optimization and scalability',
  ];

  const prefix = prefixes[Math.floor(Math.random() * prefixes.length)];
  const suffix = suffixes[Math.floor(Math.random() * suffixes.length)];
  const text =
    itemDescription.charAt(0).toUpperCase() + itemDescription.slice(1).toLowerCase();

  return `${prefix} ${text} — ${suffix}`;
}

export async function generatePaymentTerms(_config?: AIConfig): Promise<string> {
  return paymentTerms[Math.floor(Math.random() * paymentTerms.length)];
}

export async function generateInvoiceNotes(_config?: AIConfig): Promise<string> {
  return invoiceNotes[Math.floor(Math.random() * invoiceNotes.length)];
}

export async function generateInvoiceEmail(
  customerName: string,
  totalAmount: string,
  invoiceNumber: string,
  tone: 'professional' | 'friendly' | 'formal' | 'reminder' = 'professional',
  companyName: string = 'Your Company',
  _config?: AIConfig
): Promise<string> {
  const generator = emailTemplates[tone];
  return generator(customerName, totalAmount, invoiceNumber, companyName);
}

// Real API integration (optional - set API key to enable)
export async function generateWithOpenAI(
  prompt: string,
  apiKey: string
): Promise<string> {
  try {
    const response = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${apiKey}`,
      },
      body: JSON.stringify({
        model: 'gpt-4o-mini',
        messages: [{ role: 'user', content: prompt }],
        max_tokens: 300,
        temperature: 0.7,
      }),
    });

    if (!response.ok) throw new Error('OpenAI API error');
    const data = await response.json();
    return data.choices[0].message.content;
  } catch {
    throw new Error('Failed to generate with OpenAI');
  }
}

export async function generateWithGemini(
  prompt: string,
  apiKey: string
): Promise<string> {
  try {
    const response = await fetch(
      `https://generativelanguage.googleapis.com/v1beta/models/gemini-pro:generateContent?key=${apiKey}`,
      {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          contents: [{ parts: [{ text: prompt }] }],
        }),
      }
    );

    if (!response.ok) throw new Error('Gemini API error');
    const data = await response.json();
    return data.candidates[0].content.parts[0].text;
  } catch {
    throw new Error('Failed to generate with Gemini');
  }
}
