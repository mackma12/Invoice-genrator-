import jsPDF from 'jspdf';
import { InvoiceData, templates } from '../types';

export async function generatePDF(
  invoice: InvoiceData,
  templateId: string = 'modern',
  openInNewTab: boolean = false
): Promise<void> {
  const doc = new jsPDF('p', 'mm', 'a4');
  const pageWidth = doc.internal.pageSize.getWidth();
  const pageHeight = doc.internal.pageSize.getHeight();
  const margin = 20;
  const contentWidth = pageWidth - margin * 2;

  const template = templates.find((t) => t.id === templateId) || templates[0];
  const primaryColor = template.primaryColor;

  let y = 0;

  const checkPage = (neededHeight: number) => {
    if (y + neededHeight > pageHeight - margin) {
      doc.addPage();
      y = margin;
      return true;
    }
    return false;
  };

  // ---- HEADER ----
  doc.setFillColor(primaryColor);
  doc.rect(0, 0, pageWidth, 55, 'F');

  doc.setTextColor(255, 255, 255);
  doc.setFontSize(24);
  doc.setFont('helvetica', 'bold');
  doc.text(invoice.company.name || 'Your Company', margin, 22);

  doc.setFontSize(16);
  doc.setFont('helvetica', 'normal');
  const label = 'INVOICE';
  const labelWidth = doc.getTextWidth(label);
  doc.text(label, pageWidth - margin - labelWidth, 22);

  doc.setFontSize(10);
  doc.text(`Invoice #: ${invoice.invoiceNumber}`, pageWidth - margin - labelWidth, 30);
  doc.text(`Date: ${invoice.invoiceDate}`, pageWidth - margin - labelWidth, 36);
  doc.text(`Due Date: ${invoice.dueDate}`, pageWidth - margin - labelWidth, 42);

  y = 65;

  // ---- BILL TO / FROM ----
  doc.setFontSize(9);
  doc.setTextColor(100, 100, 100);
  doc.setFont('helvetica', 'bold');
  doc.text('FROM:', margin, y);
  doc.text('BILL TO:', pageWidth / 2 + 5, y);

  y += 6;
  doc.setFont('helvetica', 'normal');
  doc.setTextColor(50, 50, 50);
  doc.setFontSize(10);

  const companyLines: string[] = [
    invoice.company.name,
    invoice.company.address,
    invoice.company.city
      ? `${invoice.company.city}, ${invoice.company.state} ${invoice.company.zip}`
      : '',
    invoice.company.country,
    `GSTIN: ${invoice.company.gstin || 'N/A'}`,
    `Email: ${invoice.company.email || 'N/A'}`,
    `Phone: ${invoice.company.phone || 'N/A'}`,
  ].filter((l): l is string => Boolean(l));

  const customerLines: string[] = [
    invoice.customer.name,
    invoice.customer.address,
    invoice.customer.city
      ? `${invoice.customer.city}, ${invoice.customer.state} ${invoice.customer.zip}`
      : '',
    invoice.customer.country,
    `GSTIN: ${invoice.customer.gstin || 'N/A'}`,
    `Email: ${invoice.customer.email || 'N/A'}`,
    `Phone: ${invoice.customer.phone || 'N/A'}`,
  ].filter((l): l is string => Boolean(l));

  const maxLines = Math.max(companyLines.length, customerLines.length);
  for (let i = 0; i < maxLines; i++) {
    if (i < companyLines.length) {
      doc.setFontSize(i === 0 ? 11 : 9);
      doc.setFont('helvetica', i === 0 ? 'bold' : 'normal');
      doc.text(companyLines[i], margin, y + i * 5);
    }
    if (i < customerLines.length) {
      doc.setFontSize(i === 0 ? 11 : 9);
      doc.setFont('helvetica', i === 0 ? 'bold' : 'normal');
      doc.text(customerLines[i], pageWidth / 2 + 5, y + i * 5);
    }
  }

  y += maxLines * 5 + 10;

  // ---- TABLE HEADER ----
  doc.setFillColor(primaryColor);
  doc.rect(margin, y, contentWidth, 9, 'F');

  doc.setTextColor(255, 255, 255);
  doc.setFontSize(9);
  doc.setFont('helvetica', 'bold');

  const colWidths = [10, contentWidth * 0.42, 18, 22, 18, 22];
  const headers = ['#', 'Description', 'Qty', 'Rate', 'GST %', 'Amount'];
  let x = margin + 2;
  headers.forEach((header, i) => {
    doc.text(header, x, y + 6);
    x += colWidths[i];
  });

  y += 9;

  // ---- TABLE ROWS ----
  doc.setTextColor(50, 50, 50);
  let subtotal = 0;

  invoice.items.forEach((item, index) => {
    checkPage(30);

    const bg: [number, number, number] = index % 2 === 0 ? [248, 248, 250] : [255, 255, 255];
    doc.setFillColor(bg[0], bg[1], bg[2]);
    doc.rect(margin, y, contentWidth, 8, 'F');

    const itemAmount = item.quantity * item.rate * (1 - item.discount / 100);
    const gstAmount = itemAmount * (item.gst / 100);
    const totalAmount = itemAmount + gstAmount;
    subtotal += itemAmount;

    doc.setFontSize(9);
    doc.setFont('helvetica', 'normal');

    let cx = margin + 2;
    doc.text(String(index + 1), cx, y + 5.5);
    cx += colWidths[0];

    const desc = item.description || 'Item';
    const maxDescWidth = colWidths[1] - 2;
    const truncated =
      doc.getTextWidth(desc) > maxDescWidth
        ? desc.substring(0, Math.floor(maxDescWidth / 1.8)) + '...'
        : desc;
    doc.text(truncated, cx, y + 5.5);
    cx += colWidths[1];

    doc.text(String(item.quantity), cx, y + 5.5, { align: 'center' });
    cx += colWidths[2];

    doc.text(`${invoice.currency}${item.rate.toFixed(2)}`, cx, y + 5.5, { align: 'right' });
    cx += colWidths[3];

    doc.text(`${item.gst}%`, cx, y + 5.5, { align: 'center' });
    cx += colWidths[4];

    doc.text(`${invoice.currency}${totalAmount.toFixed(2)}`, cx, y + 5.5, { align: 'right' });

    y += 8;
  });

  y += 4;

  // ---- TOTALS ----
  checkPage(50);
  const totalsWidth = 75;
  const totalsX = pageWidth - margin - totalsWidth;

  const totalGst = invoice.items.reduce((sum, item) => {
    const amount = item.quantity * item.rate * (1 - item.discount / 100);
    return sum + amount * (item.gst / 100);
  }, 0);

  const totalDiscount = invoice.items.reduce((sum, item) => {
    const amount = item.quantity * item.rate;
    return sum + (amount * item.discount) / 100;
  }, 0);

  const grandTotal = subtotal + totalGst;

  const totals: [string, string][] = [
    ['Subtotal', `${invoice.currency}${subtotal.toFixed(2)}`],
    ...(totalDiscount > 0
      ? ([['Discount', `-${invoice.currency}${totalDiscount.toFixed(2)}`]] as [string, string][])
      : []),
    ['GST', `${invoice.currency}${totalGst.toFixed(2)}`],
  ];

  totals.forEach(([label, value]) => {
    doc.setFontSize(10);
    doc.setFont('helvetica', 'normal');
    doc.setTextColor(100, 100, 100);
    doc.text(label, totalsX, y);
    doc.text(value, pageWidth - margin, y, { align: 'right' });
    y += 7;
  });

  // Grand total
  doc.setFillColor(primaryColor);
  doc.roundedRect(totalsX, y - 1, totalsWidth, 10, 1, 1, 'F');
  doc.setTextColor(255, 255, 255);
  doc.setFontSize(11);
  doc.setFont('helvetica', 'bold');
  doc.text('TOTAL', totalsX + 3, y + 5);
  doc.text(`${invoice.currency}${grandTotal.toFixed(2)}`, pageWidth - margin - 3, y + 5, {
    align: 'right',
  });

  y += 18;

  // ---- BANK DETAILS ----
  if (invoice.bankName || invoice.accountNumber) {
    checkPage(40);
    doc.setDrawColor(primaryColor);
    doc.setLineWidth(0.5);
    doc.line(margin, y, pageWidth - margin, y);
    y += 6;

    doc.setTextColor(primaryColor);
    doc.setFontSize(11);
    doc.setFont('helvetica', 'bold');
    doc.text('Payment Details', margin, y);
    y += 6;

    doc.setFontSize(9);
    doc.setTextColor(50, 50, 50);
    doc.setFont('helvetica', 'normal');

    if (invoice.bankName) {
      doc.text(`Bank: ${invoice.bankName}`, margin, y);
      y += 5;
    }
    if (invoice.accountNumber) {
      doc.text(`Account No: ${invoice.accountNumber}`, margin, y);
      y += 5;
    }
    if (invoice.ifscCode) {
      doc.text(`IFSC Code: ${invoice.ifscCode}`, margin, y);
      y += 5;
    }
  }

  // ---- NOTES & TERMS ----
  if (invoice.notes || invoice.paymentTerms) {
    checkPage(30);
    y += 4;
    doc.setDrawColor(primaryColor);
    doc.setLineWidth(0.5);
    doc.line(margin, y, pageWidth - margin, y);
    y += 6;

    if (invoice.notes) {
      doc.setTextColor(primaryColor);
      doc.setFontSize(10);
      doc.setFont('helvetica', 'bold');
      doc.text('Notes', margin, y);
      y += 5;

      doc.setFontSize(8);
      doc.setTextColor(80, 80, 80);
      doc.setFont('helvetica', 'normal');
      const noteLines: string[] = doc.splitTextToSize(invoice.notes, contentWidth);
      noteLines.forEach((line: string) => {
        checkPage(5);
        doc.text(line, margin, y);
        y += 4;
      });
      y += 4;
    }

    if (invoice.paymentTerms) {
      doc.setTextColor(primaryColor);
      doc.setFontSize(10);
      doc.setFont('helvetica', 'bold');
      doc.text('Payment Terms', margin, y);
      y += 5;

      doc.setFontSize(8);
      doc.setTextColor(80, 80, 80);
      doc.setFont('helvetica', 'normal');
      const termsLines: string[] = doc.splitTextToSize(invoice.paymentTerms, contentWidth);
      termsLines.forEach((line: string) => {
        checkPage(5);
        doc.text(line, margin, y);
        y += 4;
      });
    }
  }

  // ---- FOOTER ----
  const footerY = pageHeight - 15;
  doc.setFillColor(245, 245, 250);
  doc.rect(0, footerY, pageWidth, 15, 'F');
  doc.setTextColor(150, 150, 150);
  doc.setFontSize(8);
  doc.setFont('helvetica', 'normal');
  doc.text(
    `Generated by InvoiceAI — ${invoice.company.website || 'Your Company'}`,
    pageWidth / 2,
    footerY + 8,
    { align: 'center' }
  );

  // ---- SIGNATURE ----
  if (invoice.signature) {
    const sigX = pageWidth - margin - 50;
    doc.setTextColor(50, 50, 50);
    doc.setFontSize(10);
    doc.setFont('helvetica', 'bold');
    doc.text(invoice.signature, sigX, y + 10);
    doc.setDrawColor(100, 100, 100);
    doc.setLineWidth(0.3);
    doc.line(sigX, y + 12, sigX + 50, y + 12);
    doc.setFontSize(7);
    doc.setFont('helvetica', 'normal');
    doc.setTextColor(150, 150, 150);
    doc.text('Authorized Signatory', sigX + 25, y + 16, { align: 'center' });
  }

  if (openInNewTab) {
    const blob = doc.output('blob');
    const url = URL.createObjectURL(blob);
    window.open(url, '_blank');
  } else {
    doc.save(`Invoice_${invoice.invoiceNumber}.pdf`);
  }
}
